from maluforce.core import Maluforce
from maluforce.reportutils import adjust_report,lod_rename,to_lod
from maluforce.fileutils import save_lod_files,read_lod_file,read_lod_files